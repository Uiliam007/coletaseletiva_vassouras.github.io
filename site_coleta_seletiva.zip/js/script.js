const map = L.map('map').setView([-23.5505, -46.6333], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap'
}).addTo(map);

function registrarPonto() {
  navigator.geolocation.getCurrentPosition(pos => {
    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    const status = document.getElementById('status').value;
    const obs = document.getElementById('obs').value;

    const cor = status === 'coletado' ? 'green' : 'red';

    const marker = L.circleMarker([lat, lng], {
      radius: 8,
      color: cor,
      fillColor: cor,
      fillOpacity: 0.8
    }).addTo(map);

    marker.bindPopup(`<b>Status:</b> ${status}<br><b>Obs:</b> ${obs}`);
  });
}
